USE [BizTalkCloud9Common]

DECLARE @practice NVARCHAR(50) = 'internalsd-gulfcoast'	-- Replace with Practice Name

-- The emdeonUserID must be configured. 
-- 277 Unsolicited comes with this value to figure it out the Practice Information
-- emdeonUserID format is a 10 digits string 'XXXXXXXXXX'. e.g.: '0000000473'

SELECT	pcName, emdeonUserID, pcsStatusID, pcInstanceAddress, pcInstanceConnectionString 
FROM	[BTS].PracticeConfig
WHERE	pcName = @practice

-- Verify the schema is update, and the stored procedure exists
DECLARE @emdeonUserID NVARCHAR(10) = '0000000473'

EXEC [BTS].[GetPracticeConfigurationByEmdeonUser] @emdeonUserID