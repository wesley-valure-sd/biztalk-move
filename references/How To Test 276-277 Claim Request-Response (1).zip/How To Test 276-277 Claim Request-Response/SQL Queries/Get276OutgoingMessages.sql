USE [BizTalkCloud9Common]

-- Get most recent 276 outgoing messages
	-- stsStatusID = 0 -> Not processed
	-- stsStatusID = 1 -> Processed

SELECT	TOP 10  * 
FROM	BTS.OutgoingMessage 
WHERE	omMessageType = 276
ORDER BY omCreateDateTime DESC
