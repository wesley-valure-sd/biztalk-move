USE [InternalSd-gulfcoast]

-- Set Claim to Ready to Send for re-testing

DECLARE @claimNumber INT = 39213		-- Replace with Claim Number to test

-- Delete any previous error identified
DELETE FROM ADAClaimError WHERE adaClaimGUID IN (SELECT adaClaimGUID FROM ADAClaim WHERE adaClaimNumber = @claimNumber) 

-- Set to Ready to Send
UPDATE ADAClaim SET csGUID = '2DCF97DE-359F-4348-A147-737593A82E27' WHERE adaClaimNumber = @claimNumber