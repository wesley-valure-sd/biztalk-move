  USE [InternalSd-gulfcoast]

-- EXPECTED RESULTS
--	> We MUST see only the Claims that we plan to test

DECLARE @readyStatusGUID UNIQUEIDENTIFIER = (SELECT csGUID FROM dbo.ClaimStatus WHERE csCode='READYTOSEND' AND ISNULL(csDeleted,0)=0);
DECLARE @printedStatusGUID UNIQUEIDENTIFIER = (SELECT csGUID FROM dbo.ClaimStatus WHERE csCode='PRINTED' AND ISNULL(csDeleted,0)=0);

SELECT	a.adaclaimGUID,
		a.adaclaimNumber,
		a.adaclaimStatus,
		s.csDescription as CurrentStatus,
		a.patGUID,
		a.adaclaimDateTime,
		a.pipGUID,
		a.adaclaimTotal
FROM	ADAClaim a JOIN ClaimStatus s ON a.csGUID = s.csGUID
WHERE	a.csGUID in ( @readyStatusGUID, @printedStatusGUID )