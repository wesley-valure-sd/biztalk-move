USE [InternalSd-gulfcoast]

-- Check if there were errors with the Claim

DECLARE @claimNumber INT = 8918	-- Replace with Claim Number

SELECT	a.adaclaimNumber,
		e.*,
		c.cecCode,
		c.cecMessage
FROM	ADAClaimError e
		JOIN ADAClaim a ON e.adaclaimGUID = a.adaclaimGUID
		JOIN ClaimErrorCode c ON e.cecGUID = c.cecGUID
WHERE	a.adaclaimNumber IN (@claimNumber)