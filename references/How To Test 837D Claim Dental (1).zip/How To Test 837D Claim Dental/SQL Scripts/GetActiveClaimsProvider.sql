USE [InternalSd-gulfcoast]

-- CHECK Active Claims Provider

-- EXPECTED RESULTS
--	> ActiveClientProvider	
--		ChangeHealthcareEDI or DentalXChangeEDI for EDI processing
--		ChangeHealthcare or DentalXChange for DCDS processing
-- 
-- IMPORTANT NOTE FOR Change Healthcare EDI
	--	When the Change Healthcare EDI is the Active Claims Provider it enables the 837D Claim Request integration.
	--  The 837D integration automatically detect and process the claims in Ready to Send status.
	--	The 837D integration check for pracEmdeonIsTest to determine what CHC API URL to use. 

-- Get Emdeon Settings (ChangeHealthcare)

SELECT	pracActiveClientProvider,
		CASE WHEN pracActiveClientProvider = 0 THEN 'ChangeHealthcare' 
		WHEN pracActiveClientProvider = 1 THEN 'DentalXChange'
		WHEN pracActiveClientProvider = 2 THEN 'ChangeHealthcareEDI'
		WHEN pracActiveClientProvider = 3 THEN 'DentalXChangeEDI'
		ELSE 'None' END AS ActiveClientProvider,
		pracEmdeonIsTest,		-- Send as Test Claims
		pracEmdeonUserID,		-- User ID
		pracEmdeonPassword,		-- Password ID
		pracEmdeonSubmitterID,	-- Submitter ID
		pracEmdeonVendorID,		-- Vendor ID
		pracTIN,
		pracEmdeonURL,
		pracEmdeonTestURL,
		pracDeleted
FROM	Practice